# PhoneAI

An AI assistant that runs on your Galaxy S20 FE and uses the phone for you:
text people, open apps, tap, type, scroll, set alarms, flashlight, volume, brightness, and more.
You talk or type. Works with Anthropic, OpenAI, Gemini, OpenRouter, Groq, xAI or any OpenAI-compatible API (the model must support tool calling).

## Install it (pick one)

### A) Android Studio (easiest to change things later)
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > choose this `PhoneAI` folder. Wait for "Gradle sync" to finish.
3. On your phone: Settings > About phone > Software information > tap "Build number" 7 times.
   Then Settings > Developer options > turn on USB debugging.
4. Plug the phone into the PC, accept the prompt on the phone, press the green Run button.

### B) No Android Studio (GitHub builds the APK for you)
1. Make a free GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo > Actions > "Build APK" > wait ~5 minutes.
3. Open the finished run > Artifacts > download `PhoneAI-apk`, unzip, copy `app-debug.apk` to the phone and tap it.
   (Allow "install unknown apps" for your file manager if asked.)

## First-time setup inside the app
1. Tap the gear icon. Paste your API key. Provider is detected automatically, or pick it from the list. For other services choose Custom and enter the Base URL (e.g. https://api.example.com/v1) and a model name.
2. Go down the list and tap Grant on each row.
3. Phone control is the important one. On Android 13+ the switch is greyed out at first:
   open "App info" from the row, tap the 3 dots (top right), tap "Allow restricted settings",
   then go back to Accessibility and switch PhoneAI on.
4. Go back to the chat and try: "What's on my screen?" or "Turn the flashlight on".

## Features
- Chat with an AI that can see your screen and act (tap, type, scroll, swipe, back/home/recents)
- Open any app, open links, maps, dialer
- Send texts, find contacts, make calls (with an Allow / Deny card, can be turned off)
- Alarms, timers, flashlight, volume, brightness, clipboard, battery and time
- Voice input (mic button) and optional spoken replies
- Red STOP button floats over any app while it works
- Save your favourite commands as shortcuts (hold one of your messages; hold a shortcut to remove it)
- Keeps working when you switch to other apps

## Notes
- Your API key is stored only on the phone. Usage is billed by your provider to your key.
- Android blocks a few things for every app: banking/password screens can't be read, Wi-Fi/Bluetooth can't be
  toggled, apps can't be installed silently.
- You can change the model name in Settings if a newer one comes out.
