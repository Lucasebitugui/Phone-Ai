package com.jiwd.phoneai

import android.speech.tts.TextToSpeech
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class ChatItem(val id: Long, val kind: Kind, val text: String) {
    enum class Kind { USER, AI, TOOL, ERROR }
}

/** The brain: sends your request to Claude, runs the tools Claude asks for, repeats until done. */
object Agent {
    private const val MAX_STEPS = 30

    val chat = MutableStateFlow<List<ChatItem>>(emptyList())
    val running = MutableStateFlow(false)

    private val ids = AtomicLong(0)
    private val history = mutableListOf<JSONObject>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var tts: TextToSpeech? = null

    private fun add(kind: ChatItem.Kind, text: String) {
        val item = ChatItem(ids.incrementAndGet(), kind, text)
        chat.update { it + item }
    }

    fun clear() {
        if (running.value) return
        chat.value = emptyList()
        history.clear()
    }

    fun stop() {
        job?.cancel()
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || running.value) return
        if (Prefs.apiKey.isBlank()) {
            add(ChatItem.Kind.ERROR, "Add your API key first: tap the gear icon, then Settings.")
            return
        }
        add(ChatItem.Kind.USER, t)
        running.value = true
        AgentForegroundService.start(App.instance)
        Overlay.showStop { stop() }
        job = scope.launch {
            try {
                loop(t)
            } catch (e: CancellationException) {
                add(ChatItem.Kind.ERROR, "Stopped.")
                throw e
            } catch (e: Exception) {
                add(ChatItem.Kind.ERROR, e.message ?: "Something went wrong.")
            } finally {
                running.value = false
                Overlay.hideStop()
                AgentForegroundService.stop(App.instance)
            }
        }
    }

    private suspend fun loop(userText: String) {
        history.add(JSONObject().put("role", "user").put("content", userText))
        trimHistory()
        var steps = 0
        while (steps < MAX_STEPS) {
            steps++
            shrinkOldResults()
            val resp = callApi()
            val content = resp.getJSONArray("content")
            history.add(JSONObject().put("role", "assistant").put("content", content))

            val results = JSONArray()
            var lastText = ""
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                when (b.optString("type")) {
                    "text" -> {
                        val t = b.optString("text", "").trim()
                        if (t.isNotEmpty()) {
                            add(ChatItem.Kind.AI, t)
                            lastText = t
                        }
                    }
                    "tool_use" -> {
                        val id = b.getString("id")
                        val name = b.getString("name")
                        val input = b.optJSONObject("input") ?: JSONObject()
                        add(ChatItem.Kind.TOOL, describe(name, input))
                        val out = runTool(name, input)
                        results.put(
                            JSONObject().put("type", "tool_result").put("tool_use_id", id).put("content", out)
                        )
                    }
                }
            }
            if (results.length() == 0) {
                if (lastText.isNotEmpty()) speak(lastText)
                return
            }
            history.add(JSONObject().put("role", "user").put("content", results))
        }
        add(ChatItem.Kind.ERROR, "I hit my step limit. Tell me to continue if you want me to keep going.")
    }

    private suspend fun runTool(name: String, input: JSONObject): String {
        if (Tools.isSensitive(name) && Prefs.confirmSensitive) {
            if (!Overlay.canDraw()) {
                return "Could not ask the user for confirmation because the overlay permission is missing. Tell the user to grant 'Display over other apps' in PhoneAI Settings."
            }
            val (title, detail) = when (name) {
                "send_sms" -> "Send this text?" to "To: ${input.optString("number")}\n\n${input.optString("message")}"
                "call_number" -> "Make this call?" to input.optString("number")
                else -> "Allow $name?" to input.toString()
            }
            if (!Overlay.confirm(title, detail)) return "The user denied this action."
        }
        return Tools.execute(name, input)
    }

    private fun describe(name: String, input: JSONObject): String {
        val args = input.keys().asSequence().joinToString(", ") { k -> "$k=${input.opt(k)}" }
        return "$name($args)".take(140)
    }

    // ---------- talking to Claude ----------

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        return """
You are PhoneAI, a personal assistant that runs on the user's own Samsung Galaxy S20 FE (Android) and controls it through tools. The user installed you and gave you these permissions on purpose.

How to work:
- Do the task, don't just describe it. Use as few steps as possible.
- UI tools (tap, type_text, scroll, open_app...) return the new screen. Elements look like: [3] Label {tap} @x,y. Use the [index] from the LATEST screen only.
- To text someone by name: find_contact first, then send_sms. Never guess a phone number.
- To search inside an app: open it, tap the search box, type_text, then press_enter.
- If the screen looks the same after an action, try something different (scroll, tap_xy, press_key back) instead of repeating.
- Never type passwords, card numbers or one-time codes unless the user gave them in this chat. If a screen asks for a login, payment or security confirmation you were not given, stop and tell the user.
- Some apps (banking, protected video) block screen reading. If that happens, say so.
- Reply in the language the user writes in (Romanian or English). Keep replies short and plain. When done, say what you did in one or two sentences.

Right now it is: $now
""".trimIndent()
    }

    private fun isPlainUser(m: JSONObject) = m.getString("role") == "user" && m.opt("content") is String

    /** Old screen dumps are big. Replace the ones the AI no longer needs. */
    private fun shrinkOldResults() {
        val keepFrom = history.size - 4
        for (i in 0 until maxOf(0, keepFrom)) {
            val m = history[i]
            val c = m.opt("content")
            if (m.getString("role") == "user" && c is JSONArray) {
                for (j in 0 until c.length()) {
                    val b = c.getJSONObject(j)
                    if (b.optString("type") == "tool_result" && b.optString("content").length > 80) {
                        b.put("content", "[old result removed]")
                    }
                }
            }
        }
    }

    private fun trimHistory() {
        while (history.size > 60) {
            val next = (1 until history.size).firstOrNull { isPlainUser(history[it]) } ?: break
            repeat(next) { history.removeAt(0) }
        }
    }

    private suspend fun callApi(): JSONObject {
        val r = Providers.resolve()
        val req = Providers.build(r, systemPrompt(), history, Tools.definitions)
        var attempt = 0
        while (true) {
            val (code, text) = post(req)
            if (code in 200..299) {
                return try {
                    Providers.parse(r, text)
                } catch (e: IllegalStateException) {
                    throw e
                } catch (e: Exception) {
                    throw IllegalStateException("Could not read the AI's answer: ${text.take(200)}")
                }
            }
            val msg = try {
                val j = JSONObject(text)
                val err = j.opt("error")
                when (err) {
                    is JSONObject -> err.optString("message", text.take(200))
                    is String -> err
                    else -> text.take(200)
                }
            } catch (e: Exception) {
                text.take(200)
            }
            if ((code == 429 || code == 529 || code >= 500) && attempt < 2) {
                attempt++
                delay(2000L * attempt)
                continue
            }
            val hint = when (code) {
                401, 403 -> " (check your API key and provider in Settings)"
                404 -> " (check the model name and Base URL in Settings)"
                else -> ""
            }
            throw IllegalStateException("API error $code: $msg$hint")
        }
    }

    private suspend fun post(req: Providers.Req): Pair<Int, String> = suspendCancellableCoroutine { cont ->
        val holder = arrayOfNulls<HttpURLConnection>(1)
        cont.invokeOnCancellation {
            try {
                holder[0]?.disconnect()
            } catch (e: Exception) {
            }
        }
        thread {
            try {
                val c = URL(req.url).openConnection() as HttpURLConnection
                holder[0] = c
                c.requestMethod = "POST"
                c.connectTimeout = 20000
                c.readTimeout = 90000
                c.doOutput = true
                req.headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
                c.outputStream.use { it.write(req.body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (cont.isActive) cont.resume(code to text)
            } catch (e: Exception) {
                if (cont.isActive) cont.resumeWithException(e)
            }
        }
    }

    // ---------- speaking replies ----------

    private fun speak(text: String) {
        if (!Prefs.speak) return
        val existing = tts
        if (existing == null) {
            tts = TextToSpeech(App.instance) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.getDefault()
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "phoneai")
                }
            }
        } else {
            existing.speak(text, TextToSpeech.QUEUE_FLUSH, null, "phoneai")
        }
    }
}
