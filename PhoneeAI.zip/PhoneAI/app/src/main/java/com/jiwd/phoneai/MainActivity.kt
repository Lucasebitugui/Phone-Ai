package com.jiwd.phoneai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

private val Bg = Color(0xFF0B0E14)
private val Panel = Color(0xFF161B26)
private val Cyan = Color(0xFF00E5FF)
private val Violet = Color(0xFF7C4DFF)
private val OnBg = Color(0xFFE6EAF2)
private val Muted = Color(0xFF8A94A8)
private val Good = Color(0xFF00E676)
private val Bad = Color(0xFFFF5252)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan,
                    secondary = Violet,
                    background = Bg,
                    surface = Panel,
                    onPrimary = Color.Black,
                    onBackground = OnBg,
                    onSurface = OnBg
                )
            ) {
                Root()
            }
        }
    }
}

@Composable
fun Root() {
    var screen by remember { mutableIntStateOf(0) }
    BackHandler(enabled = screen == 1) { screen = 0 }
    if (screen == 0) ChatScreen(onSettings = { screen = 1 }) else SettingsScreen(onBack = { screen = 0 })
}

// ======================= CHAT =======================

@Composable
fun ChatScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val chat by Agent.chat.collectAsState()
    val running by Agent.running.collectAsState()
    val routines by Prefs.routines.collectAsState()
    var input by remember { mutableStateOf("") }
    var a11y by remember { mutableStateOf(PhoneControlService.isRunning) }
    var hasKey by remember { mutableStateOf(Prefs.apiKey.isNotBlank()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        a11y = PhoneControlService.isRunning
        hasKey = Prefs.apiKey.isNotBlank()
    }
    val listState = rememberLazyListState()
    LaunchedEffect(chat.size) {
        if (chat.isNotEmpty()) listState.animateScrollToItem(chat.lastIndex)
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !t.isNullOrBlank()) Agent.send(t)
    }

    fun startVoice() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell PhoneAI what to do")
            speech.launch(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Voice input is not available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        TopBar(a11y, onSettings, onClear = { Agent.clear() })
        Box(Modifier.weight(1f)) {
            if (chat.isEmpty()) Welcome(a11y, hasKey, onSettings)
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(chat, key = { it.id }) { Bubble(it) }
            }
        }
        QuickChips(routines, enabled = !running)
        InputBar(
            value = input,
            onValue = { input = it },
            running = running,
            onSend = {
                Agent.send(input)
                input = ""
            },
            onMic = { startVoice() },
            onStop = { Agent.stop() }
        )
    }
}

@Composable
fun TopBar(a11y: Boolean, onSettings: () -> Unit, onClear: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "PhoneAI",
            style = TextStyle(
                brush = Brush.horizontalGradient(listOf(Cyan, Violet)),
                fontSize = 26.sp,
                fontWeight = FontWeight.Black
            )
        )
        Spacer(Modifier.width(12.dp))
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Panel)
                .clickable { onSettings() }
                .padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (a11y) Good else Bad)
            )
            Spacer(Modifier.width(6.dp))
            Text(if (a11y) "Control ON" else "Control OFF", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onClear) { Icon(Icons.Default.Delete, "Clear chat", tint = Muted) }
        IconButton(onClick = onSettings) { Icon(Icons.Default.SettingsIcon, "Settings", tint = Muted) }
    }
}

@Composable
fun Welcome(a11y: Boolean, hasKey: Boolean, onSettings: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Your phone, on autopilot",
            style = TextStyle(
                brush = Brush.horizontalGradient(listOf(Cyan, Violet)),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "Try:\n\"Text Alex I'll be 10 minutes late\"\n\"Open Spotify and play something chill\"\n\"Set an alarm for 6:30\"\n\"What's on my screen?\"\n\nHold one of your messages to save it as a shortcut.",
            color = Muted,
            textAlign = TextAlign.Center,
            fontSize = 14.sp
        )
        if (!a11y || !hasKey) {
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Bad, RoundedCornerShape(16.dp))
                    .clickable { onSettings() }
                    .padding(16.dp)
            ) {
                val todo = buildList {
                    if (!hasKey) add("add your API key")
                    if (!a11y) add("turn on phone control")
                }
                Text("Finish setup: " + todo.joinToString(" and ") + ". Tap here.", color = Bad, fontSize = 14.sp)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Bubble(m: ChatItem) {
    val ctx = LocalContext.current
    when (m.kind) {
        ChatItem.Kind.USER -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(
                Modifier
                    .widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp))
                    .background(Brush.horizontalGradient(listOf(Violet, Color(0xFF3D5AFE))))
                    .combinedClickable(
                        onClick = {},
                        onLongClick = {
                            Prefs.addRoutine(m.text)
                            Toast.makeText(ctx, "Saved as a shortcut", Toast.LENGTH_SHORT).show()
                        }
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) { Text(m.text, color = Color.White) }
        }
        ChatItem.Kind.AI -> Row(Modifier.fillMaxWidth()) {
            Box(
                Modifier
                    .widthIn(max = 320.dp)
                    .clip(RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp))
                    .background(Panel)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) { Text(m.text, color = OnBg) }
        }
        ChatItem.Kind.TOOL -> Text(
            "> " + m.text,
            color = Cyan.copy(alpha = 0.7f),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 6.dp)
        )
        ChatItem.Kind.ERROR -> Box(
            Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Bad.copy(alpha = 0.15f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) { Text(m.text, color = Color(0xFFFF8A80), fontSize = 14.sp) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Chip(label: String, onClick: () -> Unit, onLong: () -> Unit = {}) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .border(1.dp, Violet.copy(alpha = 0.6f), RoundedCornerShape(50))
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(label, color = OnBg, fontSize = 13.sp) }
}

@Composable
fun QuickChips(routines: List<String>, enabled: Boolean) {
    val ctx = LocalContext.current
    val defaults = listOf(
        "What's on my screen?",
        "Battery and time",
        "Turn the flashlight on",
        "Open YouTube",
        "Set an alarm for 7:00"
    )
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(routines) { r ->
            Chip("* $r", onClick = { if (enabled) Agent.send(r) }, onLong = {
                Prefs.removeRoutine(r)
                Toast.makeText(ctx, "Shortcut removed", Toast.LENGTH_SHORT).show()
            })
        }
        items(defaults) { d ->
            Chip(d, onClick = { if (enabled) Agent.send(d) })
        }
    }
}

@Composable
fun InputBar(
    value: String,
    onValue: (String) -> Unit,
    running: Boolean,
    onSend: () -> Unit,
    onMic: () -> Unit,
    onStop: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextField(
            value = value,
            onValueChange = onValue,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Tell your phone what to do...", color = Muted) },
            shape = RoundedCornerShape(26.dp),
            maxLines = 4,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Panel,
                unfocusedContainerColor = Panel,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = OnBg,
                unfocusedTextColor = OnBg,
                cursorColor = Cyan
            )
        )
        Spacer(Modifier.width(6.dp))
        if (running) {
            IconButton(onClick = onStop) { Icon(Icons.Default.Stop, "Stop", tint = Bad) }
        } else if (value.isBlank()) {
            IconButton(onClick = onMic) { Icon(Icons.Default.Mic, "Voice", tint = Cyan) }
        } else {
            IconButton(onClick = onSend) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Cyan) }
        }
    }
}

// ======================= SETTINGS =======================

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    @Suppress("UNUSED_VARIABLE")
    val refresh = tick // reading this makes the screen re-check permissions when you come back

    var key by remember { mutableStateOf(Prefs.apiKey) }
    var model by remember { mutableStateOf(Prefs.model) }
    var provider by remember { mutableStateOf(Prefs.provider) }
    var baseUrl by remember { mutableStateOf(Prefs.baseUrl) }
    var menuOpen by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(Prefs.confirmSensitive) }
    var speak by remember { mutableStateOf(Prefs.speak) }
    val routines by Prefs.routines.collectAsState()

    val askPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    fun open(i: Intent) {
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Can't open that screen on this phone", Toast.LENGTH_SHORT).show()
        }
    }
    val pkg = Uri.parse("package:${ctx.packageName}")

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = OnBg) }
            Text("Settings", color = OnBg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        SectionTitle("AI")
        Box(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = Providers.all.firstOrNull { it.id == provider }?.label ?: provider,
                onValueChange = {},
                readOnly = true,
                label = { Text("Provider") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            // invisible layer on top so a tap anywhere opens the menu
            Box(
                Modifier
                    .matchParentSize()
                    .clickable { menuOpen = true }
            )
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                Providers.all.forEach { p ->
                    DropdownMenuItem(
                        text = { Text(p.label) },
                        onClick = {
                            provider = p.id
                            Prefs.provider = p.id
                            menuOpen = false
                        }
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = key,
            onValueChange = {
                key = it
                Prefs.apiKey = it
            },
            label = { Text("API key") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Works with Anthropic, OpenAI, Gemini, OpenRouter, Groq, xAI or any OpenAI-compatible service. " +
                "The key stays on this phone and is only sent to the provider you picked.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
        )
        OutlinedTextField(
            value = model,
            onValueChange = {
                model = it
                Prefs.model = it
            },
            label = { Text("Model (empty = default)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = baseUrl,
            onValueChange = {
                baseUrl = it
                Prefs.baseUrl = it
            },
            label = { Text("Base URL (only for Custom)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "The AI must support tool / function calling, otherwise it can't control the phone.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
        )

        SectionTitle("Behaviour")
        ToggleRow(
            "Ask before texting or calling",
            "Shows an Allow / Deny card on top of any app. Turn off for full hands-free.",
            confirm
        ) {
            confirm = it
            Prefs.confirmSensitive = it
        }
        ToggleRow("Speak replies out loud", "The AI reads its final answer to you.", speak) {
            speak = it
            Prefs.speak = it
        }

        SectionTitle("Permissions (tap Grant on each)")
        PermRow(
            "Phone control",
            "Lets PhoneAI see the screen, tap, type and scroll. Switch PhoneAI on in Accessibility.",
            PhoneControlService.isRunning
        ) { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        PermRow(
            "Allow restricted settings",
            "Android 13+ greys out the switch above for apps installed outside the Play Store. Open App info, tap the 3 dots (top right), choose Allow restricted settings. Then go back and switch PhoneAI on.",
            PhoneControlService.isRunning,
            "App info"
        ) { open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)) }
        PermRow(
            "Display over other apps",
            "Needed for the red STOP button, the Allow / Deny card, and launching apps while working.",
            Settings.canDrawOverlays(ctx)
        ) { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) }
        PermRow(
            "Texts, contacts and calls",
            "Lets PhoneAI send SMS, look up contact numbers and place calls.",
            has(Manifest.permission.SEND_SMS) && has(Manifest.permission.READ_CONTACTS) && has(Manifest.permission.CALL_PHONE)
        ) {
            askPerms.launch(
                arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
            )
        }
        PermRow(
            "Change system settings",
            "Needed to change screen brightness.",
            Settings.System.canWrite(ctx)
        ) { open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg)) }
        if (Build.VERSION.SDK_INT >= 33) {
            PermRow(
                "Notifications",
                "Shows the 'PhoneAI is working' notice while it runs.",
                has(Manifest.permission.POST_NOTIFICATIONS)
            ) { askPerms.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS)) }
        }
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        PermRow(
            "Run in background",
            "Stops Android from putting PhoneAI to sleep in the middle of a task.",
            pm.isIgnoringBatteryOptimizations(ctx.packageName)
        ) { open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)) }

        if (routines.isNotEmpty()) {
            SectionTitle("Saved shortcuts")
            routines.forEach { r ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(r, color = OnBg, modifier = Modifier.weight(1f), fontSize = 14.sp)
                    IconButton(onClick = { Prefs.removeRoutine(r) }) {
                        Icon(Icons.Default.Delete, "Remove", tint = Muted)
                    }
                }
            }
        }

        SectionTitle("Good to know")
        Text(
            "Android itself blocks a few things for every app: banking and password screens can't be read, Wi-Fi and Bluetooth can't be toggled, and apps can't be installed silently. Everything else is up to you and the AI.",
            color = Muted, fontSize = 13.sp
        )
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        color = Cyan,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 22.dp, bottom = 8.dp)
    )
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = OnBg, fontSize = 15.sp)
            Text(sub, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Cyan, checkedThumbColor = Color.Black)
        )
    }
}

@Composable
fun PermRow(title: String, desc: String, granted: Boolean, action: String = "Grant", onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Panel)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (granted) Good else Bad)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = OnBg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(desc, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        if (!granted) {
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Color.White)
            ) { Text(action) }
        } else {
            Text("OK", color = Good, fontWeight = FontWeight.Bold)
        }
    }
}
