package com.jiwd.phoneai

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicLong

/**
 * Lets the app work with different AI providers.
 * Internally the chat history always stays in Anthropic format (see Agent.kt).
 * Here we convert it to what each provider expects, and convert the answer back.
 */
object Providers {

    /** kind: "anthropic", "openai" (any OpenAI-compatible API) or "gemini" */
    data class Resolved(val id: String, val kind: String, val baseUrl: String, val model: String)

    class Req(val url: String, val headers: Map<String, String>, val body: String)

    data class Info(val id: String, val label: String, val kind: String, val baseUrl: String, val model: String)

    val all = listOf(
        Info("auto", "Auto-detect from key", "", "", ""),
        Info("anthropic", "Anthropic (Claude)", "anthropic", "https://api.anthropic.com", "claude-sonnet-5-5"),
        Info("openai", "OpenAI", "openai", "https://api.openai.com/v1", "gpt-4o"),
        Info("gemini", "Google Gemini", "gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash"),
        Info("openrouter", "OpenRouter", "openai", "https://openrouter.ai/api/v1", "openai/gpt-4o"),
        Info("groq", "Groq", "openai", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
        Info("xai", "xAI (Grok)", "openai", "https://api.x.ai/v1", "grok-2-latest"),
        Info("custom", "Custom (OpenAI-compatible URL)", "openai", "", "")
    )

    fun detect(key: String): String = when {
        key.startsWith("sk-ant-") -> "anthropic"
        key.startsWith("AIza") -> "gemini"
        key.startsWith("sk-or-") -> "openrouter"
        key.startsWith("gsk_") -> "groq"
        key.startsWith("xai-") -> "xai"
        key.startsWith("sk-") -> "openai"
        Prefs.baseUrl.isNotBlank() -> "custom"
        else -> "openai"
    }

    fun resolve(): Resolved {
        val key = Prefs.apiKey
        var id = Prefs.provider
        if (id == "auto" || all.none { it.id == id }) id = detect(key)
        val info = all.first { it.id == id }
        val base = Prefs.baseUrl.trim().ifBlank { info.baseUrl }.trimEnd('/')
        if (base.isBlank()) {
            throw IllegalStateException("Set the Base URL in Settings (for example https://api.example.com/v1).")
        }
        var model = Prefs.model.trim()
        // An old Claude model name makes no sense for another provider.
        if (model.isBlank() || (info.kind != "anthropic" && id != "openrouter" && id != "custom" && model.startsWith("claude"))) {
            model = info.model
        }
        if (model.isBlank()) throw IllegalStateException("Type a model name in Settings.")
        return Resolved(id, info.kind, base, model)
    }

    // ---------------------------------------------------------------- build

    fun build(r: Resolved, system: String, history: List<JSONObject>, tools: JSONArray): Req = when (r.kind) {
        "anthropic" -> buildAnthropic(r, system, history, tools)
        "gemini" -> buildGemini(r, system, history, tools)
        else -> buildOpenAi(r, system, history, tools)
    }

    private fun buildAnthropic(r: Resolved, system: String, history: List<JSONObject>, tools: JSONArray): Req {
        val body = JSONObject()
            .put("model", r.model)
            .put("max_tokens", 2048)
            .put("system", system)
            .put("tools", tools)
            .put("messages", JSONArray(history))
            .toString()
        return Req(
            r.baseUrl + "/v1/messages",
            mapOf(
                "content-type" to "application/json",
                "x-api-key" to Prefs.apiKey,
                "anthropic-version" to "2023-06-01"
            ),
            body
        )
    }

    private fun buildOpenAi(r: Resolved, system: String, history: List<JSONObject>, tools: JSONArray): Req {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        for (m in history) {
            val role = m.getString("role")
            val c = m.opt("content")
            if (c is String) {
                msgs.put(JSONObject().put("role", role).put("content", c))
            } else if (c is JSONArray) {
                if (role == "assistant") {
                    val text = StringBuilder()
                    val calls = JSONArray()
                    for (i in 0 until c.length()) {
                        val b = c.getJSONObject(i)
                        when (b.optString("type")) {
                            "text" -> text.append(b.optString("text"))
                            "tool_use" -> calls.put(
                                JSONObject()
                                    .put("id", b.getString("id"))
                                    .put("type", "function")
                                    .put(
                                        "function", JSONObject()
                                            .put("name", b.getString("name"))
                                            .put("arguments", (b.optJSONObject("input") ?: JSONObject()).toString())
                                    )
                            )
                        }
                    }
                    val o = JSONObject().put("role", "assistant").put("content", text.toString())
                    if (calls.length() > 0) o.put("tool_calls", calls)
                    msgs.put(o)
                } else {
                    for (i in 0 until c.length()) {
                        val b = c.getJSONObject(i)
                        if (b.optString("type") == "tool_result") {
                            msgs.put(
                                JSONObject().put("role", "tool")
                                    .put("tool_call_id", b.getString("tool_use_id"))
                                    .put("content", b.optString("content"))
                            )
                        }
                    }
                }
            }
        }
        val fns = JSONArray()
        for (i in 0 until tools.length()) {
            val t = tools.getJSONObject(i)
            fns.put(
                JSONObject().put("type", "function").put(
                    "function", JSONObject()
                        .put("name", t.getString("name"))
                        .put("description", t.optString("description"))
                        .put("parameters", t.getJSONObject("input_schema"))
                )
            )
        }
        val body = JSONObject()
            .put("model", r.model)
            .put("messages", msgs)
            .put("tools", fns)
            .toString()
        val headers = mutableMapOf(
            "content-type" to "application/json",
            "authorization" to "Bearer ${Prefs.apiKey}"
        )
        if (r.id == "openrouter") headers["x-title"] = "PhoneAI"
        return Req(r.baseUrl + "/chat/completions", headers, body)
    }

    // Gemini has no tool-call ids, so we make our own and remember the signatures it sends.
    private val gIds = AtomicLong(0)
    private val gSigs = HashMap<String, String>()

    private fun buildGemini(r: Resolved, system: String, history: List<JSONObject>, tools: JSONArray): Req {
        // tool_use id -> function name (needed for functionResponse)
        val names = HashMap<String, String>()
        for (m in history) {
            val c = m.opt("content")
            if (m.getString("role") == "assistant" && c is JSONArray) {
                for (i in 0 until c.length()) {
                    val b = c.getJSONObject(i)
                    if (b.optString("type") == "tool_use") names[b.getString("id")] = b.getString("name")
                }
            }
        }
        val contents = JSONArray()
        for (m in history) {
            val role = m.getString("role")
            val c = m.opt("content")
            val parts = JSONArray()
            if (c is String) {
                parts.put(JSONObject().put("text", c))
            } else if (c is JSONArray) {
                for (i in 0 until c.length()) {
                    val b = c.getJSONObject(i)
                    when (b.optString("type")) {
                        "text" -> if (b.optString("text").isNotEmpty()) parts.put(JSONObject().put("text", b.getString("text")))
                        "tool_use" -> {
                            val p = JSONObject().put(
                                "functionCall", JSONObject()
                                    .put("name", b.getString("name"))
                                    .put("args", b.optJSONObject("input") ?: JSONObject())
                            )
                            gSigs[b.getString("id")]?.let { p.put("thoughtSignature", it) }
                            parts.put(p)
                        }
                        "tool_result" -> {
                            val id = b.getString("tool_use_id")
                            parts.put(
                                JSONObject().put(
                                    "functionResponse", JSONObject()
                                        .put("name", names[id] ?: "tool")
                                        .put("response", JSONObject().put("result", b.optString("content")))
                                )
                            )
                        }
                    }
                }
            }
            if (parts.length() == 0) continue
            contents.put(JSONObject().put("role", if (role == "assistant") "model" else "user").put("parts", parts))
        }
        val decls = JSONArray()
        for (i in 0 until tools.length()) {
            val t = tools.getJSONObject(i)
            val d = JSONObject().put("name", t.getString("name")).put("description", t.optString("description"))
            val schema = t.getJSONObject("input_schema")
            val props = schema.optJSONObject("properties")
            if (props != null && props.length() > 0) {
                val p = JSONObject().put("type", "object").put("properties", props)
                val req = schema.optJSONArray("required")
                if (req != null && req.length() > 0) p.put("required", req)
                d.put("parameters", p)
            }
            decls.put(d)
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 2048))
            .toString()
        return Req(
            "${r.baseUrl}/models/${r.model}:generateContent",
            mapOf("content-type" to "application/json", "x-goog-api-key" to Prefs.apiKey),
            body
        )
    }

    // ---------------------------------------------------------------- parse

    /** Turns any provider's answer into Anthropic format: {"content":[{type:text|tool_use,...}]} */
    fun parse(r: Resolved, text: String): JSONObject = when (r.kind) {
        "anthropic" -> JSONObject(text)
        "gemini" -> parseGemini(text)
        else -> parseOpenAi(text)
    }

    private fun parseOpenAi(text: String): JSONObject {
        val root = JSONObject(text)
        val choices = root.optJSONArray("choices")
        if (choices == null || choices.length() == 0) throw IllegalStateException("Empty answer from the AI: ${text.take(200)}")
        val msg = choices.getJSONObject(0).getJSONObject("message")
        val out = JSONArray()
        val content = msg.opt("content")
        if (content is String && content.isNotBlank()) {
            out.put(JSONObject().put("type", "text").put("text", content))
        } else if (content is JSONArray) {
            for (i in 0 until content.length()) {
                val t = content.optJSONObject(i)?.optString("text").orEmpty()
                if (t.isNotBlank()) out.put(JSONObject().put("type", "text").put("text", t))
            }
        }
        val calls = msg.optJSONArray("tool_calls")
        if (calls != null) {
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                val f = c.getJSONObject("function")
                val args = try {
                    JSONObject(f.optString("arguments", "{}").ifBlank { "{}" })
                } catch (e: Exception) {
                    JSONObject()
                }
                out.put(
                    JSONObject().put("type", "tool_use")
                        .put("id", c.optString("id").ifBlank { "call_${gIds.incrementAndGet()}" })
                        .put("name", f.getString("name"))
                        .put("input", args)
                )
            }
        }
        return JSONObject().put("content", out)
    }

    private fun parseGemini(text: String): JSONObject {
        val root = JSONObject(text)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val why = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw IllegalStateException("The AI gave no answer" + if (why.isNotBlank()) " ($why)." else ".")
        }
        val cand = cands.getJSONObject(0)
        val parts = cand.optJSONObject("content")?.optJSONArray("parts")
        val out = JSONArray()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                val fc = p.optJSONObject("functionCall")
                if (fc != null) {
                    val id = "g_${gIds.incrementAndGet()}"
                    p.optString("thoughtSignature").takeIf { it.isNotEmpty() }?.let { gSigs[id] = it }
                    out.put(
                        JSONObject().put("type", "tool_use").put("id", id)
                            .put("name", fc.getString("name"))
                            .put("input", fc.optJSONObject("args") ?: JSONObject())
                    )
                } else if (!p.optBoolean("thought", false)) {
                    val t = p.optString("text", "")
                    if (t.isNotBlank()) out.put(JSONObject().put("type", "text").put("text", t))
                }
            }
        }
        if (out.length() == 0) {
            val fr = cand.optString("finishReason")
            throw IllegalStateException("The AI gave an empty answer" + if (fr.isNotBlank()) " ($fr)." else ".")
        }
        return JSONObject().put("content", out)
    }
}
