package com.jiwd.phoneai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * The "hands" of PhoneAI. Once you switch it on in Accessibility settings it can
 * read what is on screen and tap, type and scroll.
 */
class PhoneControlService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: PhoneControlService? = null
        val isRunning: Boolean get() = instance != null
    }

    private val nodes = ArrayList<AccessibilityNodeInfo>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun currentPackage(): String = rootInActiveWindow?.packageName?.toString() ?: "unknown"

    // ---------- reading the screen ----------

    fun dump(maxChars: Int = 6000): String {
        val root = rootInActiveWindow
            ?: return "No readable window (screen locked, or this app blocks screen reading)."
        nodes.clear()
        val sb = StringBuilder("Current app: ${root.packageName}\n")
        walk(root, sb, maxChars, 0)
        if (nodes.isEmpty()) sb.append("(no readable elements - try tap_xy or press_key)\n")
        if (sb.length > maxChars) sb.append("...(truncated, scroll for more)\n")
        return sb.toString()
    }

    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder, max: Int, depth: Int) {
        if (n == null || sb.length > max || depth > 40) return
        if (n.isVisibleToUser) {
            var label = (n.text ?: n.contentDescription ?: n.hintText)?.toString()
                ?.replace("\n", " ")?.take(100) ?: ""
            if (label.isBlank()) {
                label = n.viewIdResourceName?.substringAfter("/") ?: ""
            }
            val interactive = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable
            if (label.isNotBlank() || interactive) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val flags = ArrayList<String>()
                if (n.isClickable) flags.add("tap")
                if (n.isEditable) flags.add("input")
                if (n.isScrollable) flags.add("scroll")
                if (n.isCheckable) flags.add(if (n.isChecked) "on" else "off")
                nodes.add(n)
                sb.append("[").append(nodes.size - 1).append("] ")
                sb.append(if (label.isBlank()) "(no label)" else label)
                if (flags.isNotEmpty()) sb.append(" {").append(flags.joinToString(",")).append("}")
                sb.append(" @").append(r.centerX()).append(",").append(r.centerY()).append("\n")
            }
        }
        for (i in 0 until n.childCount) {
            walk(n.getChild(i), sb, max, depth + 1)
        }
    }

    // ---------- tapping and typing ----------

    private suspend fun clickNode(n: AccessibilityNodeInfo, name: String): String {
        var cur: AccessibilityNodeInfo? = n
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return "Tapped $name"
            }
            cur = cur.parent
            hops++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapXY(r.exactCenterX(), r.exactCenterY(), 50)
    }

    suspend fun tapIndex(i: Int): String {
        val n = nodes.getOrNull(i) ?: return "No element [$i] - read the screen again."
        return clickNode(n, "[$i]")
    }

    suspend fun tapText(text: String): String {
        val root = rootInActiveWindow ?: return "No readable window."
        val found = root.findAccessibilityNodeInfosByText(text)
        if (found.isNullOrEmpty()) return "No element with text '$text' on screen."
        val n = found.firstOrNull { it.isVisibleToUser } ?: found[0]
        return clickNode(n, "'$text'")
    }

    suspend fun tapXY(x: Float, y: Float, duration: Long = 50): String {
        val p = Path()
        p.moveTo(x, y)
        return if (gesture(p, duration.coerceAtLeast(1L))) "Tapped (${x.toInt()}, ${y.toInt()})"
        else "Tap gesture failed"
    }

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long = 350): String {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        return if (gesture(p, duration)) "Swiped" else "Swipe failed"
    }

    suspend fun scroll(direction: String): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        // "down" = show content further down = finger moves up
        return when (direction) {
            "down" -> swipe(w / 2, h * 0.72f, w / 2, h * 0.28f)
            "up" -> swipe(w / 2, h * 0.28f, w / 2, h * 0.72f)
            "right" -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)
            "left" -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)
            else -> "Unknown direction '$direction'"
        }
    }

    fun typeText(text: String, index: Int?): String {
        val target = if (index != null) {
            nodes.getOrNull(index)
        } else {
            rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: nodes.firstOrNull { it.isEditable }
        }
        if (target == null) return "No text field found. Tap a text field first."
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed text"
        else "Could not type into that element"
    }

    fun pressEnter(): String {
        if (Build.VERSION.SDK_INT < 30) {
            return "Enter key not supported on this Android version - tap the search/send button instead."
        }
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return "No focused text field."
        return if (f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) "Pressed Enter"
        else "Enter failed"
    }

    fun press(key: String): String {
        val action = when (key) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "power_menu" -> GLOBAL_ACTION_POWER_DIALOG
            "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return "Not supported on this Android version"
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return "Not supported on this Android version"
            else -> return "Unknown key '$key'"
        }
        return if (performGlobalAction(action)) "Pressed $key" else "Could not press $key"
    }

    private suspend fun gesture(path: Path, duration: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                .build()
            val started = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)
            if (!started && cont.isActive) cont.resume(false)
        }
}
