package com.jiwd.phoneai

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Things drawn on top of other apps: the red STOP button while the AI is working,
 * and the Allow / Deny card before it texts or calls.
 */
object Overlay {
    private val main = Handler(Looper.getMainLooper())
    private val ctx: Context get() = App.instance
    private val wm: WindowManager get() = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var stopView: View? = null

    fun canDraw(): Boolean = Settings.canDrawOverlays(ctx)

    private fun params(w: Int, h: Int, gravity: Int, x: Int = 0, y: Int = 0): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = gravity
        p.x = x
        p.y = y
        return p
    }

    private fun pill(color: String, radius: Float = 60f): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(Color.parseColor(color))
        d.cornerRadius = radius
        return d
    }

    fun showStop(onStop: () -> Unit) {
        if (!canDraw()) return
        main.post {
            if (stopView != null) return@post
            val v = TextView(ctx)
            v.text = "STOP"
            v.setTextColor(Color.WHITE)
            v.textSize = 13f
            v.typeface = Typeface.DEFAULT_BOLD
            v.setPadding(40, 18, 40, 18)
            v.background = pill("#E53935")
            v.setOnClickListener { onStop() }
            try {
                wm.addView(
                    v,
                    params(
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        Gravity.TOP or Gravity.END, 24, 180
                    )
                )
                stopView = v
            } catch (e: Exception) {
            }
        }
    }

    fun hideStop() {
        main.post {
            val v = stopView
            if (v != null) {
                try {
                    wm.removeView(v)
                } catch (e: Exception) {
                }
            }
            stopView = null
        }
    }

    /** Shows an Allow / Deny card on top of whatever app is open. Returns true if allowed. */
    suspend fun confirm(title: String, detail: String): Boolean = suspendCancellableCoroutine { cont ->
        if (!canDraw()) {
            cont.resume(false)
            return@suspendCancellableCoroutine
        }
        main.post {
            val card = LinearLayout(ctx)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(52, 44, 52, 32)
            card.background = pill("#1B2230", 44f)

            val titleView = TextView(ctx)
            titleView.text = title
            titleView.setTextColor(Color.parseColor("#00E5FF"))
            titleView.textSize = 18f
            titleView.typeface = Typeface.DEFAULT_BOLD
            card.addView(titleView)

            val detailView = TextView(ctx)
            detailView.text = detail
            detailView.setTextColor(Color.WHITE)
            detailView.textSize = 15f
            detailView.setPadding(0, 20, 0, 28)
            card.addView(detailView)

            var done = false
            fun finish(result: Boolean) {
                if (done) return
                done = true
                try {
                    wm.removeView(card)
                } catch (e: Exception) {
                }
                if (cont.isActive) cont.resume(result)
            }

            fun button(label: String, color: String, result: Boolean): TextView {
                val b = TextView(ctx)
                b.text = label
                b.setTextColor(Color.WHITE)
                b.textSize = 15f
                b.typeface = Typeface.DEFAULT_BOLD
                b.setPadding(44, 22, 44, 22)
                b.background = pill(color)
                b.setOnClickListener { finish(result) }
                return b
            }

            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.END
            row.addView(button("Deny", "#455A64", false))
            row.addView(View(ctx), LinearLayout.LayoutParams(24, 1))
            row.addView(button("Allow", "#00897B", true))
            card.addView(row)

            try {
                wm.addView(
                    card,
                    params(
                        (ctx.resources.displayMetrics.widthPixels * 0.9).toInt(),
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        Gravity.CENTER
                    )
                )
            } catch (e: Exception) {
                if (cont.isActive) cont.resume(false)
                return@post
            }
            cont.invokeOnCancellation { main.post { finish(false) } }
        }
    }
}
