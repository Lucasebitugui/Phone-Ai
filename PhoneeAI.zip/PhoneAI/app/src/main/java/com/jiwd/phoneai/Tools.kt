package com.jiwd.phoneai

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Everything the AI is allowed to do on the phone. */
object Tools {
    private val ctx: Context get() = App.instance

    private val sensitive = setOf("send_sms", "call_number")
    fun isSensitive(name: String) = name in sensitive

    // ---------- tool descriptions sent to the AI ----------

    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun num(d: String) = JSONObject().put("type", "number").put("description", d)
    private fun bool(d: String) = JSONObject().put("type", "boolean").put("description", d)
    private fun pick(d: String, vararg v: String) =
        JSONObject().put("type", "string").put("description", d).put("enum", JSONArray(v.toList()))

    private fun obj(required: List<String> = emptyList(), vararg props: Pair<String, JSONObject>): JSONObject {
        val p = JSONObject()
        props.forEach { p.put(it.first, it.second) }
        return JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required))
    }

    private fun def(name: String, desc: String, schema: JSONObject = obj()) =
        JSONObject().put("name", name).put("description", desc).put("input_schema", schema)

    val definitions: JSONArray by lazy {
        val a = JSONArray()
        a.put(def("read_screen", "Read everything visible on the phone screen as a numbered list. Use this to see where you are."))
        a.put(def("tap", "Tap an element by its [index] from the latest screen.", obj(listOf("index"), "index" to num("Element number, e.g. 3"))))
        a.put(def("tap_text", "Tap the element that contains this text.", obj(listOf("text"), "text" to str("Text on the element"))))
        a.put(def("tap_xy", "Tap exact screen coordinates. Use when elements have no label. Set duration_ms to 800+ for a long press.",
            obj(listOf("x", "y"), "x" to num("X pixel"), "y" to num("Y pixel"), "duration_ms" to num("Press length, default 50"))))
        a.put(def("type_text", "Type text into a text field (replaces what is in it). Without index it uses the focused or first field.",
            obj(listOf("text"), "text" to str("Text to type"), "index" to num("Optional element number of the field"))))
        a.put(def("press_enter", "Press Enter / Search / Send on the keyboard of the focused field."))
        a.put(def("scroll", "Scroll the screen. 'down' shows content further down.",
            obj(listOf("direction"), "direction" to pick("Direction", "up", "down", "left", "right"))))
        a.put(def("swipe", "Swipe between two points.",
            obj(listOf("x1", "y1", "x2", "y2"), "x1" to num("Start X"), "y1" to num("Start Y"), "x2" to num("End X"), "y2" to num("End Y"))))
        a.put(def("press_key", "Press a system button.",
            obj(listOf("key"), "key" to pick("Which button", "back", "home", "recents", "notifications", "quick_settings", "lock_screen", "screenshot", "power_menu"))))
        a.put(def("open_app", "Open an installed app by its name (e.g. 'YouTube', 'WhatsApp').", obj(listOf("name"), "name" to str("App name"))))
        a.put(def("list_apps", "List installed apps, optionally filtered by a word.", obj(emptyList(), "query" to str("Optional filter"))))
        a.put(def("open_url", "Open a link or URI: https:// pages, geo: maps, tel: dialer, mailto:, etc.", obj(listOf("url"), "url" to str("The link"))))
        a.put(def("send_sms", "Send a text message (SMS). Use find_contact first if you only have a name.",
            obj(listOf("number", "message"), "number" to str("Phone number"), "message" to str("Message text"))))
        a.put(def("find_contact", "Look up phone numbers of a contact by name.", obj(listOf("name"), "name" to str("Name or part of it"))))
        a.put(def("call_number", "Start a phone call.", obj(listOf("number"), "number" to str("Phone number"))))
        a.put(def("set_alarm", "Set an alarm.",
            obj(listOf("hour", "minute"), "hour" to num("0-23"), "minute" to num("0-59"), "label" to str("Optional label"))))
        a.put(def("set_timer", "Start a countdown timer.",
            obj(listOf("seconds"), "seconds" to num("Length in seconds"), "label" to str("Optional label"))))
        a.put(def("flashlight", "Turn the flashlight on or off.", obj(listOf("on"), "on" to bool("true = on"))))
        a.put(def("set_volume", "Set a volume level.",
            obj(listOf("percent"), "stream" to pick("Which volume (default media)", "media", "ring", "alarm", "notification"), "percent" to num("0-100"))))
        a.put(def("set_brightness", "Set screen brightness.", obj(listOf("percent"), "percent" to num("0-100"))))
        a.put(def("device_status", "Battery, time, date, device info and which app is in front."))
        a.put(def("set_clipboard", "Put text on the clipboard.", obj(listOf("text"), "text" to str("Text to copy"))))
        a.put(def("wait", "Wait a few seconds (for a page or app to load), then read the screen.", obj(emptyList(), "seconds" to num("1-10"))))
        a
    }

    // ---------- running a tool ----------

    suspend fun execute(name: String, a: JSONObject): String {
        return try {
            when (name) {
                "read_screen" -> svc().dump()
                "tap" -> withScreen(svc().tapIndex(a.getInt("index")))
                "tap_text" -> withScreen(svc().tapText(a.getString("text")))
                "tap_xy" -> withScreen(
                    svc().tapXY(a.getDouble("x").toFloat(), a.getDouble("y").toFloat(), a.optLong("duration_ms", 50L))
                )
                "type_text" -> withScreen(
                    svc().typeText(a.getString("text"), if (a.has("index")) a.getInt("index") else null), 400
                )
                "press_enter" -> withScreen(svc().pressEnter(), 1000)
                "scroll" -> withScreen(svc().scroll(a.getString("direction")))
                "swipe" -> withScreen(
                    svc().swipe(
                        a.getDouble("x1").toFloat(), a.getDouble("y1").toFloat(),
                        a.getDouble("x2").toFloat(), a.getDouble("y2").toFloat()
                    )
                )
                "press_key" -> {
                    val k = a.getString("key")
                    val r = svc().press(k)
                    if (k == "lock_screen" || k == "screenshot" || k == "power_menu") r else withScreen(r)
                }
                "open_app" -> {
                    val r = openApp(a.getString("name"))
                    if (r.startsWith("Opened")) withScreen(r, 1500) else r
                }
                "list_apps" -> listApps(a.optString("query", ""))
                "open_url" -> withScreen(openUrl(a.getString("url")), 1500)
                "send_sms" -> sendSms(a.getString("number"), a.getString("message"))
                "find_contact" -> findContact(a.getString("name"))
                "call_number" -> callNumber(a.getString("number"))
                "set_alarm" -> setAlarm(a.getInt("hour"), a.getInt("minute"), a.optString("label", ""))
                "set_timer" -> setTimer(a.getInt("seconds"), a.optString("label", ""))
                "flashlight" -> flashlight(a.getBoolean("on"))
                "set_volume" -> setVolume(a.optString("stream", "media"), a.getInt("percent"))
                "set_brightness" -> setBrightness(a.getInt("percent"))
                "device_status" -> deviceStatus()
                "set_clipboard" -> setClipboard(a.getString("text"))
                "wait" -> {
                    val s = a.optDouble("seconds", 1.0).coerceIn(0.0, 10.0)
                    withScreen("Waited ${s.toInt()}s", (s * 1000).toLong())
                }
                else -> "Unknown tool '$name'"
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "Error: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun svc(): PhoneControlService = PhoneControlService.instance
        ?: throw IllegalStateException("Phone control is OFF. Ask the user to switch PhoneAI on in Settings > Accessibility.")

    /** After an action, wait for the screen to settle and attach the new screen. */
    private suspend fun withScreen(result: String, settleMs: Long = 700): String {
        delay(settleMs)
        val s = PhoneControlService.instance?.dump(3500) ?: return result
        return "$result\n--- screen now ---\n$s"
    }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    // ---------- apps and links ----------

    private fun launchableApps(): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
    }

    private fun openApp(name: String): String {
        val apps = launchableApps()
        val q = name.trim().lowercase()
        val match = apps.firstOrNull { it.first.lowercase() == q }
            ?: apps.firstOrNull { it.first.lowercase().contains(q) }
            ?: apps.firstOrNull { it.second.lowercase().contains(q) }
            ?: return "No app found matching '$name'. Try list_apps."
        val intent = ctx.packageManager.getLaunchIntentForPackage(match.second)
            ?: return "Cannot launch ${match.first}."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "Opened ${match.first}"
    }

    private fun listApps(query: String): String {
        val q = query.trim().lowercase()
        val names = launchableApps().map { it.first }
            .filter { q.isEmpty() || it.lowercase().contains(q) }
            .sortedBy { it.lowercase() }
        if (names.isEmpty()) return "No apps match."
        return names.take(80).joinToString(", ") + if (names.size > 80) " ... (${names.size} total)" else ""
    }

    private fun openUrl(url: String): String {
        val u = if (url.contains(":")) url else "https://$url"
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "Opened $u"
    }

    // ---------- messages and calls ----------

    @Suppress("DEPRECATION")
    private fun sendSms(number: String, message: String): String {
        if (!has(Manifest.permission.SEND_SMS)) return "SMS permission not granted. Ask the user to grant it in PhoneAI Settings."
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        val parts = sm.divideMessage(message)
        if (parts.size > 1) sm.sendMultipartTextMessage(number, null, parts, null, null)
        else sm.sendTextMessage(number, null, message, null, null)
        return "SMS sent to $number"
    }

    private fun findContact(name: String): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return "Contacts permission not granted. Ask the user to grant it in PhoneAI Settings."
        val out = ArrayList<String>()
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        c?.use {
            while (it.moveToNext() && out.size < 8) {
                out.add("${it.getString(0)}: ${it.getString(1)}")
            }
        }
        return if (out.isEmpty()) "No contact matches '$name'." else out.distinct().joinToString("\n")
    }

    private fun callNumber(number: String): String {
        val uri = Uri.parse("tel:" + Uri.encode(number))
        return if (has(Manifest.permission.CALL_PHONE)) {
            ctx.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Calling $number"
        } else {
            ctx.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Phone permission missing - opened the dialer with $number instead."
        }
    }

    // ---------- clock, hardware, settings ----------

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "Alarm set for %02d:%02d".format(hour, minute)
    }

    private fun setTimer(seconds: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "Timer started for $seconds seconds"
    }

    private fun flashlight(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "No flashlight found."
        cm.setTorchMode(id, on)
        return "Flashlight ${if (on) "on" else "off"}"
    }

    private fun setVolume(stream: String, percent: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val s = when (stream) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "notification" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        val max = am.getStreamMaxVolume(s)
        val p = percent.coerceIn(0, 100)
        am.setStreamVolume(s, (max * p / 100.0).roundToInt(), AudioManager.FLAG_SHOW_UI)
        return "Set $stream volume to $p%"
    }

    private fun setBrightness(percent: Int): String {
        if (!Settings.System.canWrite(ctx)) return "Needs the 'Modify system settings' permission. Ask the user to grant it in PhoneAI Settings."
        val p = percent.coerceIn(0, 100)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * p / 100.0).roundToInt())
        return "Brightness set to $p%"
    }

    private fun deviceStatus(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val now = SimpleDateFormat("EEEE, d MMMM yyyy HH:mm", Locale.getDefault()).format(Date())
        val dm = ctx.resources.displayMetrics
        val front = PhoneControlService.instance?.currentPackage() ?: "unknown (phone control is off)"
        return "Battery: $pct%${if (bm.isCharging) " (charging)" else ""}\n" +
            "Time: $now\n" +
            "Screen: ${dm.widthPixels}x${dm.heightPixels}\n" +
            "Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}\n" +
            "Front app: $front"
    }

    private suspend fun setClipboard(text: String): String {
        withContext(Dispatchers.Main) {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("PhoneAI", text))
        }
        return "Copied to clipboard"
    }
}
